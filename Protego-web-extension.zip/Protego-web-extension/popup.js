    
    //added blacklisting
    //added blacklisted popup
    //added redirect to protego warning page
    //TODO protego warning page
    //TODO whitelising
    //TODO design ng blacklisted popup
    
document.addEventListener('DOMContentLoaded', function() {
    console.log("Popup script loaded");
    

    
    var recentURLsTable = document.getElementById('recentURLs').getElementsByTagName('tbody')[0];
    var isActive = false;
    var blacklist = [];

    chrome.storage.local.get(['isActive', 'blacklist'], function(data) {
        isActive = data.isActive || false;
        blacklist = data.blacklist || [];

        var toggleButton = document.getElementById('toggleButton');
        toggleButton.textContent = isActive ? "Deactivate" : "Activate";

        if (isActive) {
            captureURL();
        }
    });

    function captureURL() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            const currentTab = tabs[0];
            const url = currentTab.url;
            console.log("Current tab URL:", url);

            // kapag nasa blacklisted list, redirect user() ---> protego warning page
            if (blacklist.includes(url)) {
                redirectUser();
                return;
            }
            

            fetch('https://flaskurlanalysis-protego.onrender.com/process_url', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    url: url
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log("Prediction result:", data.prediction);
                updateRecentURLs(url, data.prediction);
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    }

   

    chrome.tabs.onCreated.addListener(function(tab) {
        if (isActive) {
            captureURL();
        }
    });

    var removeAllButton = document.getElementById('removeAllButton');
    removeAllButton.addEventListener('click', function() {
        removeRecentURLs();
    });

    function removeRecentURLs() {
        recentURLsTable.innerHTML = "";
    }

    function toggleActivation() {
        isActive = !isActive;
        console.log("Capturing URLs is now", isActive ? "activated" : "deactivated");
        var toggleButton = document.getElementById('toggleButton');
        toggleButton.textContent = isActive ? "Deactivate" : "Activate";
        toggleButton.style.backgroundColor = !isActive ? "" : "orange";

        chrome.storage.local.set({ 'isActive': isActive });
        if (isActive) {
            captureURL();
        }
    }

    var toggleButton = document.getElementById('toggleButton');
    toggleButton.addEventListener('click', function() {
        toggleActivation();
    });

    //add item  sa table 
    function updateRecentURLs(url, prediction) {
        
        if (recentURLsTable.rows.length > 4) {
            recentURLsTable.deleteRow(-1); 
        }
    
        var newRow = recentURLsTable.insertRow(0); 
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2); 
    
        cell1.textContent = url;
        cell2.textContent = prediction;
    
        if (prediction === "Potentially dangerous") {
            cell2.style.color = "red";
    
            var blacklistButton = document.createElement('button');
            blacklistButton.textContent = "Blacklist";
            blacklistButton.addEventListener('click', function() {
                addToBlacklist(url);
                cell3.textContent = "Added to blacklist";
            });
    
            cell3.appendChild(blacklistButton);
        } else if (prediction === "Safe website") {
            cell2.style.color = "green";
        }
    }
    


    //BLACKLISTING

    function getBlacklist(callback) {
        chrome.storage.local.get('blacklist', function(data) {
            callback(data.blacklist || []);
        });
    }

    function setBlacklist(blacklist) {
        chrome.storage.local.set({ 'blacklist': blacklist });
    }

    function addToBlacklist(url) {
        getBlacklist(function(blacklist) {
            blacklist.push(url);
            setBlacklist(blacklist);
        });
    }

    var showBlacklistButton = document.getElementById('showBlacklistButton');
    showBlacklistButton.addEventListener('click', function() {
        showBlacklist();
    });

    function showBlacklist() {
        getBlacklist(function(blacklist) {
            var blacklistPopup = window.open("", "Blacklist", "width=400,height=400");
            blacklistPopup.document.write("<h2>Blacklisted URLs</h2>");
            if (blacklist.length === 0) {
                blacklistPopup.document.write("<p>No blacklisted URLs</p>");
            } else {
                blacklist.forEach(function(url) {
                    blacklistPopup.document.write("<p>" + url + "</p>");
                });
            }
        });
    }

    //kapag nasa blacklsited list, redirect ---> Protego warning page
    function redirectUser() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            const tabId = tabs[0].id;
            chrome.tabs.update(tabId, { url: 'https://saibadev.github.io/Protego-website-deploy/warning-page.html' }); 
        });
    }
    

    //Whitelisting naman...
    function removeBlacklistUrl(){

    }
});
